# NeverLose v0.2 · 永不丢数据的本地收集工具

一个**单文件、离线、零依赖**的本地收集工具。内核信念：**输入即落盘，绝不在用户确认前刷新或覆盖**。

- 打开方式：**双击 `neverlose.html`** 即可（现代桌面浏览器），无需构建、无需服务器、无需联网。
- 存储位置：浏览器 `localStorage`，键名 `neverlose.v0.db`（数据只存在本机浏览器）。v0.2 **沿用 v0 键名**，以保证 v0→v0.2 升级时不丢失既有数据。

---

## 功能一览

| # | 需求 | 实现 |
|---|------|------|
| 1 | 单文件、内联 CSS+JS、零外部依赖 | 一个 `.html`，`<style>` 与两个 `<script>` 全部内联；无 `<link>`/`<img>`/CDN/字体/网络请求 |
| 2 | 输入即落盘 | 三个输入框（备注/姓名/内容）绑定 `input` 事件，**每次输入立即写 localStorage**，无需点保存；刷新后数据仍在 |
| 3 | 版本留存 | 每次编辑稳定后自动生成**带时间戳的快照**，可查看/回滚；内容未变自动去重 |
| 4 | 导出 | `Blob` + `a[download]` 导出 **JSON**（含版本历史）与 **CSV**（含 BOM，Excel 友好），不联网 |
| 5 | 绝不覆盖 | 清空 / 导入 / 回滚 / 删除 均先弹**自定义确认框**，且执行前**强制生成一个带标签的备份版本**；无静默覆盖 |
| 6 | 持久性防护 | 写盘失败（quota/隐私模式）时顶部红色横幅提示，**内存里的输入不丢**，恢复后自动继续保存 |
| 7 | 界面 | 中文界面：顶部导出/导入/清空，左侧条目列表，中间编辑区，右侧版本历史 |
| 8 | **全文搜索/过滤（v0.2）** | 左侧搜索框对条目 `name` 与 `content` 做**大小写不敏感**的实时子串过滤；含「✕ 清空」按钮、`匹配 N / M 条`计数；无匹配时给出明确提示 |
| 9 | **快捷键提交（v0.2）** | 在任意输入框内按 **Ctrl+Enter 或 ⌘(Cmd)+Enter** 快速提交并新建下一条，等价于点【＋ 新建条目】（提交前先固化一个版本快照） |
| 10 | **存储占用显示与告警（v0.2）** | 页脚实时显示 `存储占用 X / 5.00 MB（Y%）`；占用 **≥80%** 时顶部弹出可关闭的醒目告警（**≥95%** 升级为危险级红色告警） |

## 使用说明

- **收集**：点右上「＋ 新建条目」，在中间的「备注 / 姓名 / 内容」中直接输入即可，无需保存。
- **快速提交（v0.2）**：在任意输入框内按 `Ctrl+Enter`（macOS 上 `⌘+Enter`）即可提交当前输入并新建下一条，等同于点击【＋ 新建条目】。
- **搜索（v0.2）**：在左侧搜索框输入关键词，列表按 `姓名` 或 `内容` 实时过滤（大小写不敏感）；计数区显示匹配数；点【✕ 清空】复位。
- **存储占用（v0.2）**：页脚显示当前 localStorage 占用估算与百分比；接近上限时顶部出现可关闭的告警。
- **历史 / 回滚**：右侧「版本历史」列出每个快照的时间戳与标签；「查看」预览内容，「回滚」恢复（回滚前会自动备份当前状态）。
- **导出**：顶部「导出 JSON」（完整数据+历史）或「导出 CSV」（表格）。文件名形如 `neverlose-2026-01-01-12-00-00.json`。
- **导入**：顶部「导入」选择一个 JSON 文件，可选择「追加合并」或「替换全部」；替换前会自动备份。
- **清空**：顶部「清空」，确认后条目清空，但清空前的内容会保留为一个可回滚的版本。

## 数据结构

```json
{
  "entries": [
    { "id": "e_...", "note": "备注", "name": "姓名", "content": "内容",
      "created": "2026-01-01T12:00:00", "updated": "2026-01-01T12:00:05" }
  ],
  "activeId": "e_...",
  "versions": [
    { "id": "v_...", "ts": "2026-01-01T12:00:05", "label": "编辑快照",
      "fp": "[[...指纹...]]", "count": 1, "data": [ { "id":"...", "note":"...", "name":"...", "content":"...", "created":"...", "updated":"..." } ] }
  ]
}
```

导入兼容三种形态：完整 db 对象（`{entries:[...]}`）、条目数组（`[...]`）、单个条目对象；字段名兼容英文键（note/name/content）与中文键（备注/姓名/内容）。

导出 JSON 的元数据形如 `{ "app": "neverlose", "version": "v0.2", "exportedAt": ... }`。

## 关键实现位置（`neverlose.html`）

| 关注点 | 位置 |
|--------|------|
| 纯逻辑核心（可被 node 单测提取） | `/* NL-CORE-START */` … `/* NL-CORE-END */`，导出到 `globalThis.NL` |
| CSV 转义 | `csvEscape`（L202） |
| 导入解析 | `parseImport`（L223） |
| 版本追加 / 去重 / 上限 / force | `pushVersion`（L244） |
| 条目→CSV | `entriesToCsv`（L269） |
| **条目全文过滤（v0.2）** | `filterEntries`（L280） |
| **UTF-16 字节估算（v0.2）** | `estimateBytes`（L292） |
| **存储占用/告警状态计算（v0.2）** | `storageStatus`（L302），阈值常量 `STORAGE_LIMIT_BYTES`/`STORAGE_WARN_PERCENT`/`STORAGE_DANGER_PERCENT` |
| **提交快捷键判定（v0.2）** | `isSubmitShortcut`（L323） |
| 持久化键 / 版本上限 / 去抖 / 应用版本 | `STORAGE_KEY`、`MAX_VERSIONS`、`SNAPSHOT_DEBOUNCE_MS`、`APP_VERSION`（L356–360） |
| 读盘 / 写盘（含失败处理 + 刷新占用） | `load`（L371）、`save`（L387） |
| 输入即落盘 | `onFieldInput`（L479），绑定于输入框的 `input` 监听 |
| 版本快照 | `scheduleSnapshot`（L490）、`snapshotNow`（L494） |
| 确认弹框 | `askDialog`（L506） |
| 回滚（先备份） | `rollbackTo`（L542） |
| 清空（先备份） | `clearAll`（L575） |
| 删除（先备份） | `deleteEntry`（L592） |
| 新建条目 / **快捷键提交（v0.2）** | `newEntry`（L609）、`submitEntry`（L619） |
| 导出 JSON / CSV / 下载 | `exportJson`（L643）、`exportCsv`（L647）、`download`（L634） |
| 导入（追加/替换，替换先备份） | `doImport`（L653） |
| **搜索查询读取 / 占用计算 / 格式化 / 状态刷新（v0.2）** | `currentQuery`（L420）、`currentStorageBytes`（L421）、`fmtBytes`（L423）、`updateStorageStatus`（L429） |

## 设计取舍与限制（v0.2）

- **快照去抖**：每次按键都生成版本会迅速撑爆存储，因此「编辑稳定 700ms 后」或「输入框失焦时」生成快照（`SNAPSHOT_DEBOUNCE_MS`）。这不影响「输入即落盘」——实时保存是每个 `input` 事件都做的。
- **版本去重**：内容与上一个快照完全相同则跳过；但**危险操作前的备份用 `force` 强制新增**，保证审计记录一定存在。
- **版本上限** `MAX_VERSIONS = 500`：超过后丢弃最旧快照并在顶部提示（当前条目数据不受影响）。极端场景可调大，但需注意 localStorage 容量（通常约 5MB）。
- **搜索为纯内存过滤（v0.2）**：`filterEntries` 只对内存中的 `db.entries` 做子串匹配，不写盘、不改变数据；查询为空/纯空白时返回全部条目。
- **存储占用为估算（v0.2）**：`estimateBytes` 以「JSON 字符串长度 × 2」近似 localStorage 的 UTF-16 占用；`storageStatus` 默认以 **5 MiB** 为上限、**80%** 触发告警、**95%** 为危险级。浏览器真实配额以引擎为准，此估算仅用于提前预警。
- **快捷键（v0.2）**：`submitEntry` 会先固化一个「提交快照」再调用 `newEntry`，因此提交不会丢失当前输入，且行为与点击【＋ 新建条目】一致。
- **存储介质**：localStorage 同步、简单、双击可用；不适合超大文本。若需要更大容量可改用 IndexedDB（本版本未做）。
- 数据仅存在**这一台浏览器**里，换浏览器/清缓存会丢失——请定期用「导出 JSON」备份。

## 版本历史

- **v0.2**：
  - 新增条目**全文搜索/过滤**（`filterEntries` + 搜索框/清空按钮/匹配计数/无匹配提示）。
  - 新增 **Ctrl/⌘+Enter 快速提交**（`isSubmitShortcut` + `submitEntry`）。
  - 新增**存储占用显示与接近上限告警**（`estimateBytes`、`storageStatus`、`updateStorageStatus`，可关闭）。
  - 内部版本号提升（标题/页内标识/页脚/导出元数据/README 同步）。
  - `localStorage` 键名沿用 `neverlose.v0.db`，保证升级不丢既有数据。
- **v0**：初始版本（单文件离线、输入即落盘、版本留存、导出/导入、绝不覆盖、存储失败防护）。

## 开发自测（dev-only，非产品依赖）

产品本身零依赖；以下脚本仅用于开发期验证，可选：

```bash
cd projects/neverlose
python3 check_structure.py   # HTML 结构完整性 + 离线（无外部引用）检查
node selftest.js             # 核心纯函数单测（CSV 转义、版本去重/上限/force、导入解析、搜索过滤、字节估算、存储告警、快捷键判定）
bash build_dist.sh           # 重建 dist/（neverlose.html 逐字节一致 + 打包 zip）
```

- `check_structure.py`：用 `html.parser` 校验存在 `<html>/<head>/<body>`、关键 DOM id（含 v0.2 的 `searchInput`/`btnClearSearch`/`searchCount`/`storageAlert`/`btnDismissStorage`/`storageStatus`/`appVersion` 等）、关键函数名（含 `filterEntries`/`estimateBytes`/`storageStatus`/`isSubmitShortcut`/`submitEntry`/`updateStorageStatus`）、v0.2 版本标识与三项增值功能标记，并断言无 `http(s)://`、无 `url(http`、无 `@import`、无 CDN 域名。
- `selftest.js`：从 HTML 中提取 `NL-CORE` 代码块，在 `vm` 隔离上下文中执行并断言核心纯函数行为（含 v0.2 新增的 `filterEntries`/`estimateBytes`/`storageStatus`/`isSubmitShortcut`）。

> 注：`check_structure.py` 与 `selftest.js` 是开发期测试文件，**不参与产品运行**；产品运行只需 `neverlose.html` 一个文件。

## v0.2 新增
- 标签/分类：每条目可填写「标签」，列表上方可按标签过滤（大小写不敏感的子串匹配）。
- 排序：列表可按「最近更新 / 最早更新 / 按名称 / 创建时间」排序。
- 导出 Markdown：除 JSON / CSV 外，新增一键导出 .md（标题 + 标签/备注/时间 + 内容）。
- 兼容：沿用 localStorage 键 `neverlose.v0.db`，v0/v0.1 既有数据升级后不丢失。
